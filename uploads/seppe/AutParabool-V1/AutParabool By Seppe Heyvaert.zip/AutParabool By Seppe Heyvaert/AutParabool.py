import matplotlib.pyplot as plt
import math
import numpy as np
import tkinter as tk
from tabulate import tabulate
import ctypes
ctypes.windll.kernel32.SetConsoleTitleW("AutParabool By Seppe Heyvaert")

a = float(input("Geef a: "))
b = float(input("Geef b: "))
c = float(input("Geef c: "))
D= b**2-4*a*c

x = np.linspace(-10, 10, 1000)
y = a * x**2 + b * x + c
if a > 0:
   SP1 = "+"
   SP2 = "-"
   SP3 = "+"
   print("                  ")
   print("parabool is een Dalparabool")
   print("                  ")
   
   
else:
   SP1 = "-"
   SP2 = "+"
   SP3 = "-"
   print("                  ")
   print("parabool is een Bergparabool")
   print("                  ")


if D > 0:
   D= math.sqrt(D)

   G = (-b-D)/(2*a)
   H = (-b+D)/(2*a)
   G= round(G,2)
   H= round(H,2)
   if a < 0:
      H = (-b-D)/(2*a)
      G = (-b+D)/(2*a)
      
   print("   x|"+" -∞"+"       "+ str(round(G,1)) +"       "+ str(round(G,1)) +"       "+"+∞")
   print("-----------------------------------------")
   print("f(x)|"+"   "+"   "+SP1+"     "+ "0" +"    "+SP2+"    "+ "0" +"    "+SP3+"   "+"  ")
   print("                  ")
   print("                  ")
   print("Snijpunten zijn: "+"("+str(round(G,1))+",0)"+" en "+"("+str(round(G,1))+",0)")
if D == 0:
   G = (-b-D)/(2*a)
   G= round(G)
   H = ""
   print("   x|"+" -∞"+"       "+ str(round(G,1)) +"       "+"+∞")
   print("-----------------------------------------")
   print("f(x)|"+"   "+"   "+SP1+"     "+ "0" +"    "+SP3+"  ")
   print("                  ")
   print("                  ")
   print("Snijpunt is : "+"("+str(round(G,1))+",0)")
   
if D < 0:
   G = "Geen Snijpunt"
   H = "Geen Snijpunt"
   print("Discriminant is Negatief!")






   


coeffs = [c, b, a]
roots = np.roots(coeffs)
root = tk.Tk()
root.title("AutParabool By Seppe Heyvaert")

if np.isreal(roots).all():
    roots_string = "Kijk in Console voor Tekentabel/snijpunten."
else:
    real_roots = roots[np.isreal(roots)]
    roots_string = "Kijk in Console voor Tekentabel/snijpunten."


label = tk.Label(root, text=roots_string, font=("TkDefaultFont", 14))
label.pack()

plt.plot(x, y)
plt.axhline(0, color='black', lw=1)
plt.axvline(0, color='black', lw=1)
if D > 0:
   plt.scatter(G, 0)
   plt.scatter(H, 0)
   
if D == 0:
   plt.scatter(G, 0)

plt.xlim(-10, 10)
plt.ylim(-10, 10)
plt.xticks(np.arange(-10, 11, 1))
plt.yticks(np.arange(-10, 11, 1))
plt.xlabel('X axis')
plt.ylabel('Y axis')
plt.title('Parabool')
plt.grid(True)
plt.show()



root.mainloop()
